#ifndef AutoTrapdoorRelease_H
#define AutoTrapdoorRelease_H

#include <Commands/CommandGroup.h>

class AutoTrapdoorRelease : public CommandGroup {
public:
	AutoTrapdoorRelease();
};

#endif  // AutoTrapdoorRelease_H
