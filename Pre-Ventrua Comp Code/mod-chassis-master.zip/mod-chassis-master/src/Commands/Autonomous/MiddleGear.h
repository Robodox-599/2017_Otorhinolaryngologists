#ifndef MiddleGear_H
#define MiddleGear_H

#include <Commands/CommandGroup.h>

class MiddleGear : public CommandGroup {
public:
	MiddleGear();
};

#endif  // MiddleGear_H
